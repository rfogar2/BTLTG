//
//  AppDelegate.h
//  Bluetooth Tester
//
//  Created by LTG Ugrad on 3/24/15.
//  Copyright (c) 2015 LTG Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

