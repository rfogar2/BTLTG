//
//  ViewController.m
//  Bluetooth Tester
//
//  Created by LTG Ugrad on 3/24/15.
//  Copyright (c) 2015 LTG Ugrad. All rights reserved.
//
//Sources:
// http://www.pocketmagic.net/bluetooth-and-ios-use-bluetooth-in-your-iphone-apps/#.UahOYZUeVeW
// http://www.devx.com/wireless/Article/43502

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, weak) IBOutlet UIButton *connectButton;
@property (nonatomic, weak) IBOutlet UITextView *statsTextView;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addTextToStatsTextView:(NSString *)textToAdd
{
    NSString * currentStatText = _statsTextView.text;
    currentStatText = [currentStatText stringByAppendingString:textToAdd];
    currentStatText = [currentStatText stringByAppendingString:@"\n"];
    _statsTextView.text = currentStatText;
    
    //Make sure textview is scrolled all the way to the bottom
    [_statsTextView scrollRangeToVisible:NSMakeRange([_statsTextView.text length], 0)];
}

-(IBAction)onConnectClicked:(id)sender
{
    //Setting up the bluetooth here
    
    //Write something to the Stats Text view to make sure it's updating
    [self addTextToStatsTextView:@"Testing TextView"];
}
@end
