//
//  BTAboutViewController.h
//  Bluetooth
//
//  Created by Radu on 7/12/12.
//  Copyright (c) 2012 Radu Motisan. All rights reserved.
// http://www.pocketmagic.net/?p=2827
//

#import <UIKit/UIKit.h>

@interface BTAboutViewController : UIViewController {

    
}
@property (retain, nonatomic) IBOutlet UITextView *myTextView;
@property (retain, nonatomic) IBOutlet UIWebView *myWebView;

@end
