//
//  ViewController.h
//  BluetoothGamekitTester
//
//  Created by LTG Ugrad on 3/25/15.
//  Copyright (c) 2015 LTG Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GameKit/GameKit.h>

@interface ViewController : UIViewController {
    GKSession *currentSession;
    IBOutlet UITextField *txtMessage;
    IBOutlet UIButton *connect;
    IBOutlet UIButton *discconect;
}

@property (nonatomic, retain) GKSession *currentSession;
@property (nonatomic, retain) IBOutlet UITextField *txtMessage;
@property (nonatomic, retain) UIButton *connect;
@property (nonatomic, retain) UIButton *disconnect;

-(IBAction) btnSend:(id) sender;
-(IBAction) btnConnect:(id) sender;
-(IBAction) btnDisconnect:(id) sender;


@end

