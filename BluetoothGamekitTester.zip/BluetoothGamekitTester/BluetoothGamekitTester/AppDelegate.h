//
//  AppDelegate.h
//  BluetoothGamekitTester
//
//  Created by LTG Ugrad on 3/25/15.
//  Copyright (c) 2015 LTG Ugrad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

